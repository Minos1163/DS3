export enum SupportedLanguages {
    JavaScript = 'javascript',
    TypeScript = 'typescript',
    Python = 'python',
    Java = 'java',
    C = 'c',
    CPlusPlus = 'cpp',
    CSharp = 'csharp',
    Go = 'go',
    Rust = 'rust',
    PHP = 'php',
    // Ruby = 'ruby',
    Swift = 'swift',
}